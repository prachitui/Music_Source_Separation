from enum import Enum

import numpy as np


class ReadMode(Enum):
    READ_VIDEO = 1
    READ_AUDIO = 2


_supported_pix_fmts = {
    "rgb24": (3, np.uint8),
    "bgr24": (3, np.uint8),
    "gray": (1, np.uint8),
}


_supported_audio_fmts = {
    "f64le": np.float64,
    "f32le": np.float32,
}