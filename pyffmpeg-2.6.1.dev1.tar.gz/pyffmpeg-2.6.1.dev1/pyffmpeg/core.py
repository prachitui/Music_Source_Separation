import os
import subprocess as sp
import json
import re

from .defs import ReadMode, _supported_pix_fmts, _supported_audio_fmts
from .helpers import deprecated
import numpy as np

import validators

__author__ = 'Christian Weigel'
__copyright__ = "Fraunhofer IDMT"


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


class FFmpegVideoException(Exception):
    """Exception class used by the ``FFmpegVideoReader``"""
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def message(self):
        """
        Returns the exceptions message.
        :return: str Message
        """
        return self.args[0]


def _check_executable(executable):
    try:
        sp.check_output([executable, "-version"])
    except FileNotFoundError as err:
        err_msg = "Unable to find executable '{}'. See output.".format(executable)
        raise FFmpegVideoException(err_msg) from err
    except sp.CalledProcessError as err:
        err_msg = "Unable to execute '{}'. See output.".format(executable)
        raise FFmpegVideoException(err_msg) from err

class FFmpegMediaInfo:
    """
    The FFmpegVideoInfo contains information about a video opened with
    the ``FFmpegVideoReader``.
    """
    def __init__(self, width=0, height=0, frames=0, time_base=None,
                 duration_ts=0, has_video=False, has_audio=False,
                 audio_time_base=None, audio_duration_ts=0, audio_sample_rate=0,
                 audio_channels=0, audio_num_samples=0):
        self.width = width
        self.height = height
        self.frames = frames
        self.time_base = time_base
        self.duration_ts = duration_ts
        self.has_video = has_video
        self.has_audio = has_audio

        self.audio_time_base = audio_time_base
        self.audio_duration_ts = audio_duration_ts
        self.audio_sample_rate = audio_sample_rate
        self.audio_num_samples = audio_num_samples
        self.audio_channels = audio_channels

    def video_fps(self):
        if not self.has_video:
            return None
        return self.frames / self.video_duration()

    def video_aspect_ratio(self):
        if not self.has_video:
            return None
        return float(self.width) / float(self.height)

    def video_duration(self):
        if not self.has_video:
            return None
        if self.time_base is None:
            return 0.0
        tb_num, tb_den = self.time_base.split('/')
        dur_seconds = self.duration_ts * float(tb_num) / float(tb_den)
        return dur_seconds
        pass

    def audio_duration(self):
        if not self.has_audio:
            return None
        if self.audio_time_base is None:
            return 0.0
        tb_num, tb_den = self.audio_time_base.split('/')
        dur_seconds = self.audio_duration_ts * float(tb_num) / float(tb_den)
        return dur_seconds


# keeping the name for compatibility reasons
@deprecated("use FFmpegMediaInfo instead")
class FFmpegVideoInfo(FFmpegMediaInfo):

    @deprecated("use FFmpegMediaInfo.video_fps() instead")
    def fps(self):
        return self.video_fps()

    @deprecated("use FFmpegMediaInfo.video_aspect_ratio() instead")
    def ratio(self):
        return self.video_aspect_ratio()

    @deprecated("use attribute FFmpegMediaInfo.has_audio instead")
    def has_audio(self):
        return self.has_audio


class FFmpegMediaReader:
    """
    The FFmpegVideoReader allows reading of video files with external ffmpeg and ffprobe tools.
    It provides the frames as numpy arrays for further processing. It supports a limited number
    of ffmpeg filters.

    TODO: support multiple video streams
    """
    def __init__(self, ffmpeg_exec="ffmpeg", ffprobe_exec="ffprobe"):
        """
        Constructs a new FFmpeg video reader object.

        If used without arguments ffmpeg and ffprobe tools must be in PATH in order to be executed. Use arguments
        to specify for alternative location.

        Example usage:

          while True:
            n = video.frame_index
            ms = video.frame_ms
            success, frame = video.read()
            if not success:
                break
            yield frame, n, ms

        :param str ffmpeg_exec: Path to ffmpeg executable or command to run ffmpeg
        :param str ffprobe_exec: Path to ffprobe executable or command to run ffprobe
        """
        self.ffmpeg = ffmpeg_exec
        self.ffprobe = ffprobe_exec

        _check_executable(self.ffprobe)
        _check_executable(self.ffmpeg)

        # video decoding properties
        self.frame_format = "rgb24"

        # audio decoding properties
        self.audio_tgt_chunk_size_samples = 44100
        self.audio_tgt_chunk_size_seconds = None
        self.audio_tgt_chunk_size_as_seconds = False
        self.audio_tgt_format = "f64le"

        self._reset_state()

    def __del__(self):
        self.close()

    def set_video_format(self, pix_fmt, channels):
        """
        Sets the wanted video output format.

        By default the reader is set to rgb24, 3 channels. The info of the reader will always
        be update w.r.t these format settings as well as the video filter that may have set.

        :param str pix_fmt: One of FFmpeg's pixel formats, e.g. rgb24 - see ffmpeg -pix_fmts for a list
        :param int channels: Number of channels - number of channels that the specified format has
        """

        if pix_fmt not in _supported_pix_fmts.keys():
            raise ValueError("Unsupported video pix_fmt. Choose one of {}".format(_supported_pix_fmts.keys()))

        exp_channels = _supported_pix_fmts[pix_fmt][0]
        exp_type = _supported_pix_fmts[pix_fmt][1]

        if exp_channels != channels:
            raise ValueError("Number of {} channels does not match pixel format {}".format(channels, pix_fmt))

        if self.is_open():
            if self.mode == ReadMode.READ_AUDIO:
                raise RuntimeError("Setting video format in audio mode not supported!")

        self.frame_format = pix_fmt
        self.frame_channels = channels
        self.frame_dtype = np.dtype(exp_type)
        if self.pipe and self.file_name:
            self._open_pipe(self.file_name)

    def add_video_stream_filter(self, filter_syntax):
        """
        Adds a video stream filter to the reader
        Does not do any syntactical check so be sure about what you do! only a limited amount of filters
        is supported.
        :param filter_syntax: The FFmpeg's filter syntax - it's added to FFMpeg's -vf flag
        """
        if self.is_open():
            if self.mode == ReadMode.READ_AUDIO:
                raise RuntimeError("Setting video filter in audio mode not supported!")

        self.video_filters.append(filter_syntax)
        self._update_info()
        if self.pipe and self.file_name:
            self._open_pipe(self.file_name)

    def set_audio_format(self, chunk_size=44100, chunk_size_as_seconds=False, fmt="f32le"):
        """
        Sets the wanted audio output format. Based on what you set here, the read_audio_chunk method
        will return a numpy array of a type that matches the ffmpeg type and the parameters specified.

        The info of the reader will always be update w.r.t these format settings.

        :param int chunk_size: the size (duration) of samples returned by read_audio_chunk,
        can be specified in sample or seconds, depending on chunk_size_as_seconds parameter
        :param chunk_size_as_seconds: if true, chunk_size will be interpreted as second, otherwise as samples
        :param str fmt               : the ffmpeg audio format to be used as decoded output
        - shall be one of ["f64le", "f32le"]
        """

        if fmt not in _supported_audio_fmts.keys():
            raise ValueError("Unsupported audio sample format. Choose one of {}".format(_supported_audio_fmts.keys()))

        if self.is_open():
            if self.mode == ReadMode.READ_VIDEO:
                raise RuntimeError("Setting audio format in video mode not supported!")

        self.audio_tgt_chunk_size_as_seconds = chunk_size_as_seconds

        if self.audio_tgt_chunk_size_as_seconds:
            self.audio_tgt_chunk_size_seconds = chunk_size
        else:
            self.audio_tgt_chunk_size_samples = chunk_size

        self.audio_tgt_format = fmt
        self.audio_dtype = np.dtype(_supported_audio_fmts[self.audio_tgt_format])
        # self.audio_tgt_sample_rate = sample_rate
        # self.audio_tgt_channels = num_channels
        self._update_audio_info(self.info)
        if self.pipe and self.file_name:
            self._open_pipe(self.file_name)

    def open(self, file_name, mode):
        """
        Opens a media file. Any previously opened files will be closed.
        :param file_name: the name of the file
        :param mode: the mode to read the files - either ReadMode.READ_VIDEO or ReadMode.READ_AUDIO
        """

        assert isinstance(file_name, str)
        assert isinstance(mode, ReadMode)

        self.close()
        self.mode = mode

        if not (os.path.isfile(file_name) or validators.url(file_name)):
            err = "No such file or URL: {}".format(file_name)
            raise FileNotFoundError(err)

        _check_executable(self.ffprobe)
        _check_executable(self.ffmpeg)

        try:
            self.info = self._read_info(file_name)
        except ValueError as err:
            raise FFmpegVideoException(
                "Failed to read video information") from err

        self._update_info()
        self._update_audio_info(self.info)
        self._open_pipe(file_name)

        # Compute float time base
        if mode == ReadMode.READ_VIDEO:
            self.video_time_base = self._parse_timebase()

        self.file_name = file_name

    def read_frame(self):
        """
        Reads the next video frame of the first video stream index 0.

        :return: (success, frame) tuple where frame is the pixels of that frame as numpy array according to format,
        If not further frame is available, None is returned
        """
        if not self.is_open():
            return False, None

        data = self.pipe.stdout.read(self.frame_buffer_size)

        if len(data) != self.frame_buffer_size:
            _, stderr = self.pipe.communicate()
            if self.pipe.returncode != 0:
                raise FFmpegVideoException("ffmpeg error: {}".format(stderr.decode("utf-8")))
            return False, None

        self.frame_index += 1
        self.frame_ms = self.frame_index*self.video_time_base

        image = np.frombuffer(data, dtype=self.frame_dtype)
        image = image.reshape(self.frame_target_shape)

        self.pipe.stdout.flush()

        return True, image

    def read_audio_chunk(self):
        """
        Reads the next audio chunk.

        The shape of the returned array represents (samples, channels) if there is more than 1 channel

        If the chunk is retrieved at the end of the audio stream the returned vector might contain less samples
        than specified in chunk size!

        :return: (success, samples) tuple where samples are a numpy array according to the audio format set
        """
        if not self.is_open():
            return False, None

        data = self.pipe.stdout.read(self.audio_buffer_size)

        if len(data) == 0:
            _, stderr = self.pipe.communicate()
            if self.pipe.returncode != 0:
                raise FFmpegVideoException("ffmpeg error: {}".format(stderr.decode("utf-8")))
            return False, None

        audio_data = np.frombuffer(data, dtype=self.audio_dtype)

        if self.info.audio_channels > 1:
            audio_data = audio_data.reshape((-1, self.info.audio_channels))

        self.pipe.stdout.flush()

        return True, audio_data

    def close(self):
        """
        Terminated the underlying process and releases file handles.
        """
        self._close_pipeline()
        self._reset_state()

    def _close_pipeline(self):
        if not self.is_open():
            return
        self.pipe.terminate()

        while True:
            if self.pipe.poll() is not None:
                break
        if self.pipe.stdout is not None: self.pipe.stdout.close()
        if self.pipe.stderr is not None: self.pipe.stderr.close()

    def _reset_state(self):
        self.file_name = ""
        self.mode = None
        self.info = None
        self.raw_video_info = None
        self.raw_audio_info = None
        self.pipe = None
        self.has_video_stream = None
        self.has_audio_stream = None

        # video decoding properties
        self.frame_buffer_size = 0
        self.frame_target_shape = (0, 0)
        self.frame_index = 0
        self.frame_ms = 0.0
        self.frame_channels = _supported_pix_fmts[self.frame_format][0]
        self.frame_dtype = np.dtype(_supported_pix_fmts[self.frame_format][1])
        self.video_filters = list()
        self.video_time_base = 0.0
        # list of ffmpeg filters that are supported - if you like to add a new filters make sure that
        # metadata such as current frame index , frame size, of data type are update accordingly
        # (example: frame rate filters, crop filters, rate or pixel format conversion filters, etc.)
        self.supported_filters = ["scale", "yadif", "hflip", "vflip"]
        self.audio_dtype = np.dtype(_supported_audio_fmts[self.audio_tgt_format])
        self.audio_buffer_size = 0

    def is_open(self):
        if self.pipe is None:
            return False
        if self.pipe.poll() is not None:
            return False

        return True

    def _add_video_info(self, info_json_data, file_name, tgt_info):
        streams = info_json_data["streams"]
        fmt = info_json_data["format"]

        video_streams = [s for s in streams if s['codec_type'] == 'video']

        if len(video_streams) == 0:
            self.has_video_stream = False
            return tgt_info

        self.has_video_stream = True
        tgt_info.has_video = True

        # extract video details here
        video_stream = video_streams[0]
        self.raw_video_info = video_stream

        nb_frames = None
        if 'nb_frames' in video_stream.keys():
            if is_number(video_stream['nb_frames']) and int(video_stream['nb_frames']) > 0:
                nb_frames = int(video_stream['nb_frames'])

        tb_num, tb_den = video_stream["time_base"].split("/")
        avg_fr_num, avg_fr_den = video_stream["avg_frame_rate"].split("/") \
            if "avg_frame_rate" in video_stream.keys() else (None, None)
        r_fr_num, r_fr_den = video_stream["r_frame_rate"].split("/") \
            if "r_frame_rate" in video_stream.keys() else (None, None)
        if tb_num == avg_fr_den and tb_den == avg_fr_num:
            if 'duration_ts' in video_stream.keys():
                nb_frames_calc = int(video_stream["duration_ts"])
            else:
                nb_frames_calc = int(float(fmt["duration"]) * float(int(tb_den) / int(tb_num)))
        else:
            if avg_fr_den is not None and avg_fr_den != "0":
                framerate = float(int(avg_fr_num)) / float(int(avg_fr_den))
            elif r_fr_den is not None and r_fr_den != "0":
                framerate = float(int(r_fr_num)) / float(int(r_fr_den))
            else:
                raise FFmpegVideoException("Unsufficient video meta data to properly decode video")
            if 'duration_ts' in video_stream.keys():
                nb_frames_calc = int(float(video_stream["duration_ts"] * float(int(tb_num) / int(tb_den))) * framerate)
            else:
                nb_frames_calc = int(float(fmt["duration"]) * framerate)

        if not nb_frames:
            nb_frames = nb_frames_calc
        else:
            if nb_frames != nb_frames_calc:
                print("WARNING: Stream info mismatch for nb_frames and duration_ts: {} vs. {} for video {}. "
                      "Using nb_frames".format(nb_frames, nb_frames_calc, file_name))

        duration_ts = int(float(fmt["duration"]) * float(int(tb_den) / int(tb_num))) \
            if 'duration_ts' not in video_stream.keys() else video_stream["duration_ts"]

        tgt_info.width = video_stream["width"]
        tgt_info.height = video_stream["height"]
        tgt_info.frames = int(nb_frames)
        tgt_info.time_base = video_stream["time_base"]
        tgt_info.duration_ts = duration_ts

        return tgt_info

    def _add_audio_info(self, info_json_data, tgt_info):
        streams = info_json_data["streams"]
        audio_streams = [s for s in streams if s['codec_type'] == 'audio']

        if len(audio_streams) == 0:
            self.has_audio_stream = False
            return tgt_info
        self.raw_audio_info = audio_streams[0]
        self.has_audio_stream = True

        tgt_info.has_audio = True
        tgt_info = self._update_audio_info(tgt_info)

        return tgt_info

    def _read_info(self, file_name):
        data = sp.check_output([
            self.ffprobe,
            "-i", file_name,
            "-show_format",
            "-show_streams",
            "-print_format", "json",
            "-v", "quiet"
        ], stderr=sp.DEVNULL)

        json_data = json.loads(data.decode("utf-8"))

        media_info = FFmpegMediaInfo()
        media_info = self._add_video_info(json_data, file_name, media_info)
        media_info = self._add_audio_info(json_data, media_info)

        return media_info

    def _open_pipe(self, file_name):

        self._close_pipeline()

        if self.mode == ReadMode.READ_VIDEO:
            if not self.has_video_stream:
                self._reset_state()
                raise RuntimeError(f"Media file does not contain a video stream - {self.mode} mode not supported!")
            self._open_video_pipe(file_name)
        elif self.mode == ReadMode.READ_AUDIO:
            if not self.has_audio_stream:
                self._reset_state()
                raise RuntimeError(f"Media file does not contain an audio stream - {self.mode} mode not supported!")
            self._open_audio_pipe(file_name)
        else:
            raise ValueError("Mode not specified - might be an internal error.")

    def _open_video_pipe(self, file_name):

        command = [
            self.ffmpeg,
            "-i", file_name,
            "-f", "image2pipe",
        ]

        if self.video_filters:
            cmd_add_filters = ",".join(self.video_filters)
            command.extend([
                "-vf", "{}".format(cmd_add_filters)
            ])

        command.extend([
            "-pix_fmt", self.frame_format,
            "-c:v", "rawvideo", "-"])

        buffer_size = (
                self.info.width *
                self.info.height *
                self.frame_channels *
                self.frame_dtype.itemsize
        )

        target_shape =(self.info.height, self.info.width, self.frame_channels)

        self.pipe = sp.Popen(command, bufsize=buffer_size, stdout=sp.PIPE, stderr=sp.DEVNULL)

        self.frame_target_shape = target_shape
        self.frame_buffer_size = buffer_size

    def _open_audio_pipe(self, file_name):

        # self.audio_sample_rate = self.audio_tgt_sample_rate if self.audio_tgt_sample_rate else self.info.audio_sample_rate
        # self.audio_channels = self.audio_tgt_channels if self.audio_tgt_sample_rate else self.info.audio_channels

        command = [
            self.ffmpeg,
            '-i', file_name,
            '-f', self.audio_tgt_format,
            '-c:a', 'pcm_' + self.audio_tgt_format,
            # '-ar', str(self.audio_sample_rate),
            # '-ac', str(self.audio_channels),
            '-']

        audio_bytes_per_sample = self.audio_dtype.itemsize
        audio_frame_size = audio_bytes_per_sample * self.info.audio_channels
        self.audio_buffer_size = audio_frame_size * self.audio_tgt_chunk_size_samples

        # setting chunk size as buf size right now - check if that shall be separated
        self.pipe = sp.Popen(command, bufsize=self.audio_buffer_size, stdout=sp.PIPE, stderr=sp.DEVNULL)

    def _parse_timebase(self):
        assert self.info is not None
        num, den = self.info.time_base.split("/")

        ts_per_frame = (float(self.info.duration_ts) /
                        float(self.info.frames))

        return ts_per_frame*1000*float(num)/float(den)

    def _update_info(self):
        if not self.info:
            return
        for f in self.video_filters:
            if "scale" in f:
                n_w, n_h = self._parse_new_size(f)
                self.info.width = n_w
                self.info.height = n_h
                break

    def _update_audio_info(self, mod_info):
        if mod_info is None or self.raw_audio_info is None:
            return None

        mod_info.audio_channels = int(self.raw_audio_info["channels"])
        mod_info.audio_sample_rate = int(self.raw_audio_info["sample_rate"])
        mod_info.audio_time_base = self.raw_audio_info["time_base"]

        orig_time_base = self.raw_audio_info["time_base"]
        tb_num, tb_den = orig_time_base.split('/')

        try:
            # prioritize time stamp base duration calculation
            orig_duration_ts = self.raw_audio_info["duration_ts"]
            orig_duration = orig_duration_ts * float(tb_num) / float(tb_den)
        except KeyError:
            # try using duration entry
            try:
                orig_duration = float(self.raw_audio_info["duration"])
                orig_duration_ts = int(orig_duration * float(tb_den) / float(tb_num))
            except KeyError:
                # try using global duration timestamp entry
                orig_duration = mod_info.duration_ts * float(tb_num) / float(tb_den)
                orig_duration_ts = mod_info.duration_ts

        mod_info.audio_duration_ts = orig_duration_ts
        mod_info.audio_num_samples = int(orig_duration_ts * float(tb_num) / float(tb_den) * mod_info.audio_sample_rate)
        max_chunk_samples = mod_info.audio_num_samples

        if self.audio_tgt_chunk_size_as_seconds:
            assert self.audio_tgt_chunk_size_seconds is not None
            self.audio_tgt_chunk_size_samples = int(self.audio_tgt_chunk_size_seconds * mod_info.audio_sample_rate)

        if self.audio_tgt_chunk_size_samples > max_chunk_samples:
            self.audio_tgt_chunk_size_samples = int(max_chunk_samples)

        return mod_info

    def _parse_new_size(self, filter_syntax):
        m = re.match(r"(scale=)(.*)[:x]{1}(.*)", filter_syntax)
        if not m or len(m.groups()) < 3:
            print("WARNING: Could not retrieve video scale from filter syntax '{}'".format(filter_syntax))
            return self.info.width, self.info.height
        w_spec = m.group(2).strip()
        h_spec = m.group(3).strip()
        new_width = None
        new_height = None
        if "iw" in w_spec.lower():
            fac1, fac2 = w_spec.split("*")
            if is_number(fac1) and "iw" in fac2.lower():
                new_width = int(round(self.info.width * float(fac1)))
            else:
                if is_number(fac2) and "iw" in fac1.lower():
                    new_width = int(round(self.info.width * float(fac2)))
                else:
                    print("WARNING: Could not retrieve video scale from filter syntax '{}'".format(filter_syntax))
        else:
            new_width = w_spec

        if "ih" in h_spec.lower():
            fac1, fac2 = h_spec.split("*")
            if is_number(fac1) and "ih" in fac2.lower():
                new_height = int(round(self.info.height * float(fac1)))
            else:
                if is_number(fac2) and "ih" in fac1.lower():
                    new_height = int(round(self.info.height * float(fac2)))
                else:
                    print("WARNING: Could not retrieve video scale from filter syntax '{}'".format(filter_syntax))
        else:
            new_height = h_spec

        return int(new_width), int(new_height)


class FFmpegVideoWriter:
    """
    The FFmpegVideoWriter allows encoding of video files with FFmpeg using single rgb frame input.
    Currently the class is very limited.
    """
    def __init__(self, ffmpeg_exec="ffmpeg"):
        """
        Constructs a new FFmpeg video writer object.

        If used without arguments ffmpeg  tool must be in PATH in order to be executed. Use arguments
        to specify for alternative location.

        :param str ffmpeg_exec: Path to ffmpeg executable or command to run ffmpeg
        """
        self.ffmpeg = ffmpeg_exec
        _check_executable(self.ffmpeg)
        self.pipe = None
        self.file_name = ""
        self.fps = 25
        self.format = 'rgb24'
        self.codec = ''
        self.copy_audio = False
        self.frame_index = 0

    def open(self, file_name, codec='libx264', fps=25, copy_audio=False):
        """
        Opens the target output file and internally start the ffmpeg process

        None of the arguments is checked to be valid ffmpeg syntax. So know what you do.

        :param file_name: the ouput file name - extenstion shall be a container that can carray codec
        :param codec: the ffmpeg video codec to be used
        :param fps: the frame rate to be set with the -r paramter
        :param copy_audio: if true any available
        :return:
        """
        self.close()
        _check_executable(self.ffmpeg)
        self.file_name = file_name
        self.codec = codec
        self.fps = fps
        self.copy_audio = copy_audio

    def write(self, img):
        if not self.is_open():
            self._open_pipe(self.file_name, img)
        assert self.is_open()
        self.pipe.stdin.write(img.tostring())
        return True

    def close(self):
        if not self.is_open():
            return

        self.pipe.communicate()
        self.pipe.wait()
        self.pipe.terminate()
        self.pipe.stdin.close()
        self.pipe = None
        self.file_name = ""
        self.fps = 25
        self.format = 'rgb24'
        self.codec = ''
        self.copy_audio = False
        self.frame_index = 0

    def is_open(self):
        return self.pipe is not None

    def set_format(self, pix_fmt):
        """
        Sets the input pixel format of the np array when using write
        By default rgb24 is expected which would be a 3 channels, np.uint8() numpy input array

        :param str pix_fmt: One of FFmpeg's pixel formats, e.g. rgb24 - see ffmpeg -pix_fmts for a list
        """

        if pix_fmt not in _supported_pix_fmts.keys():
            raise FFmpegVideoException("Format no yet supported!")
        self.format = pix_fmt

    def _open_pipe(self, file_name, img):
        (height, width, c) = img.shape
        size_string = "{}x{}".format(width, height)
        audio_string = "-c:a copy" if self.copy_audio else "-an"

        expected_channels = _supported_pix_fmts[self.format][0]
        expected_nptype = _supported_pix_fmts[self.format][1]
        if c != expected_channels or img.dtype != expected_nptype:
            raise FFmpegVideoException("input image does not match expected format: {}".format(self.format))

        command = [self.ffmpeg,
                   '-y',
                   '-f', 'rawvideo',
                   '-c:v', 'rawvideo',
                   '-r', str(self.fps),
                   '-s', size_string,
                   '-pix_fmt', self.format,
                   '-i', '-',
                   '-c:v', self.codec,
                   audio_string,
                   file_name]

        buffer_size = width * height * c
        self.pipe = sp.Popen(command, stdin=sp.PIPE, stderr=sp.DEVNULL, stdout=sp.DEVNULL, bufsize=buffer_size)
        self.buffer_size = buffer_size


