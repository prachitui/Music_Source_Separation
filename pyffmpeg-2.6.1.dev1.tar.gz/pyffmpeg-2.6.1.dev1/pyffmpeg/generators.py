
from .clutil import progress_bar

__author__ = 'Christian Weigel'
__copyright__ = "Fraunhofer IDMT"


def frames(videoreader, show_progress=True):
    """
    Generator for generating frames from an FFMPEGVideoReader instance

    :param videoreader: FFMPEGVideoReader instance
    :param show_progress: if True, an interactive progress bar is shown on stdout - may collide with other outputs
    :return: yields the tuple of frame, n, ms (where n is the frame index and ms it the frame start time in ms)
    """
    n_frames = videoreader.info.frames
    if show_progress:
        with progress_bar() as progress:
            while True:
                n = videoreader.frame_index
                ms = videoreader.frame_ms
                success, frame = videoreader.read_frame()
                if not success:
                    break
                yield frame, n, ms
                progress(n / n_frames)
            progress(1.0)
    else:
        while True:
            n = videoreader.frame_index
            ms = videoreader.frame_ms
            success, frame = videoreader.read_frame()
            if not success:
                break
            yield frame, n, ms
