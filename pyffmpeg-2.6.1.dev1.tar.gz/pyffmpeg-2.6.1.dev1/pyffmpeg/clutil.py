import sys
import time
import contextlib

__author__ = 'Christian Weigel'
__copyright__ = "Fraunhofer IDMT"


def _clamp(v, minv=0, maxv=1):
    """Clamps the given value to the specified range.

    By default the range is [0, 1]. This function can be used with
    floats as well as integers, since the output type depends on
    the input type.
    """
    assert isinstance(v, int) or isinstance(v, float), \
        "Not an int or float"

    return type(v)(max(min(maxv, v), minv))


@contextlib.contextmanager
def progress_bar(fill="=", width=80, label="Progress", out=sys.stdout):
    """
    Prints a progress bar filled to value. Use this function
    together with ``with``.

    Value needs to be in range from 0.0 to 1.0. To change the fill
    character pass ``fill="<your character>"``.
    :param fill: Fill character (default: "=")
    :param width: Output width (default: 80)
    :param label: Name of the progress bar (default: "Progress")
    :param out: output function to be used - either sys.stdout or sys.stderr)
    (default: False)

    >>> val = 0.0
    >>> with progress_bar() as set_value:
    >>>     val += 0.1
    >>>     set_value(val)
    >>>
    """

    # 7 = 4 Characters percentage + space + 2*|
    bar_width = width - len(label) - 7

    def helper(val):
        val = _clamp(val, 0.0, 1.0)

        out.write("\r{} |{:<{}}|{:>4.0%}".format(
            label,
            fill*int(bar_width*val),
            bar_width,
            val))

        out.flush()

    start = time.time()
    try:
        helper(0.0)
        yield helper
    finally:
        helper(1.0)
        out.write("\n")
        out.flush()


