# pyffmpeg - Simple Python FFmpeg Wrappers

Package providing simple, easy to use wrappers for using the decoding and encoding
power of the `ffmpeg` and `ffprobe` tools in Python.

(Modified to accept files via URL)


## Dependencies

* Python >= 3.5
* [Numpy](http://www.numpy.org/) : PyFFmpeg depends on a small subset of [Numpy](http://www.numpy.org/) functions in order to generate frame data as numpy arrays.
* local installation of ffmpeg and ffprobe tools. For Windows you may download binary
distributions on https://ffmpeg.zeranoe.com/builds/. For Linux use the packages that
are provided with you distribution. For MacOSX you may use https://evermeet.cx/ffmpeg/ or
check https://www.ffmpeg.org/download.html for alternatives.

## Usage

You may use pyffmpeg either for decoding video frames or chunks of audio samples.

### FFmpegMediaReader reading video frames

```python
  import numpy as np
  from pyffmpeg import FFmpegMediaReader
  from pyffmpeg import ReadMode

  video_reader = FFmpegMediaReader()
  video_reader.open("myvideo.mp4", ReadMode.READ_VIDEO)
  # set the wanted format of the frame array - this uses a subset of ffmpeg format strings
  video_reader.set_format("bgr24", 3, np.uint8()) 

  # start the decoding loop
  while True:
    success, frame = video_reader.read()
    if not success:
        break
    # do something with the frame

```

For convenience a generator object is provided which can be used to simplify frame reading:
```python
  import numpy as np
  from pyffmpeg import FFmpegMediaReader
  from pyffmpeg import ReadMode
  from pyffmpeg import frames

  video_reader = FFmpegMediaReader()
  video_reader.open("myvideo.mp4", ReadMode.READ_VIDEO)
  # set the wanted format of the frame array - this uses a subset of ffmpeg format strings
  video_reader.set_format("bgr24", 3, np.uint8()) 

  # start the decoding loop
   for frame, n, ms in frames(video_reader, False):
     # do something with the frame


```

### FFmpegMediaReader reading audio samples

```python
  import numpy as np
  from pyffmpeg import FFmpegMediaReader
  from pyffmpeg import ReadMode

  
  audio_reader = FFmpegMediaReader()
  audio_reader.open("myvideo.mp4", ReadMode.READ_AUDIO)
  # this the array holding all audio samples - each channel in a separate column
  audio_data = np.empty((0, audio_reader.info.audio_channels), dtype=np.float32())
  # set the wanted format of the frame array - geting 1s chunks as float32 in this case 
  audio_reader.set_audio_format(audio_reader.info.audio_sample_rate, "f32le")
  while True:
      success, chunk_data = audio_reader.read_audio_chunk()
      if not success:
          break
      else:
          # you may also just process and forget the audio chunk here - instead of appending
          audio_data = np.append(audio_data, chunk_data, axis=0)
```



