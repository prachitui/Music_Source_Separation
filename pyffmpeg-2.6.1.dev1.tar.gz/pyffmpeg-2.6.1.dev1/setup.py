import os
from setuptools import setup

setup(name='pyffmpeg',
      version='2.6.1.dev1',
      author='Christian Weigel',
      author_email="christian.weigel@idmt.fraunhofer.de",
      url="https://gitserv00.idmt.fraunhofer.de/m2d/python/pyffmpeg",
      description="Simple python ffmpeg wrapper",
      long_description="Simple python ffmpeg wrapper that uses the external ffmpeg and ffprobe executable to "
                       "decode audio and video data into numpy arrays. (Modified to accept files via URL)",
      long_description_content_type="text/markdown",
      packages=['pyffmpeg'],
      python_requires=">=3.5",
      install_requires=['numpy', 'validators'],
      test_requires=['numpy', 'SoundFile'],
      )
